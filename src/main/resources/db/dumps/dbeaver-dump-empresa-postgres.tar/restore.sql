--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.3
-- Dumped by pg_dump version 14.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE empresa;
--
-- Name: empresa; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE empresa WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE empresa OWNER TO postgres;

\connect empresa

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: depart_func; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.depart_func (
    id_depart_func integer NOT NULL,
    fk_departamento integer NOT NULL,
    fk_funcionario integer NOT NULL,
    data_inicio date NOT NULL,
    data_fim date
);


ALTER TABLE public.depart_func OWNER TO postgres;

--
-- Name: departamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.departamento (
    id_departamento integer NOT NULL,
    nome character varying NOT NULL
);


ALTER TABLE public.departamento OWNER TO postgres;

--
-- Name: funcionario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.funcionario (
    id_funcionario integer NOT NULL,
    nome character varying NOT NULL,
    sobrenome character varying NOT NULL,
    data_nasc date NOT NULL,
    sexo character varying NOT NULL,
    data_admissao date NOT NULL
);


ALTER TABLE public.funcionario OWNER TO postgres;

--
-- Name: salario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.salario (
    id_salario integer NOT NULL,
    fk_funcionario integer NOT NULL,
    valor integer NOT NULL,
    data_inicio date NOT NULL,
    data_fim date
);


ALTER TABLE public.salario OWNER TO postgres;

--
-- Data for Name: depart_func; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.depart_func (id_depart_func, fk_departamento, fk_funcionario, data_inicio, data_fim) FROM stdin;
\.
COPY public.depart_func (id_depart_func, fk_departamento, fk_funcionario, data_inicio, data_fim) FROM '$$PATH$$/3332.dat';

--
-- Data for Name: departamento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.departamento (id_departamento, nome) FROM stdin;
\.
COPY public.departamento (id_departamento, nome) FROM '$$PATH$$/3330.dat';

--
-- Data for Name: funcionario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.funcionario (id_funcionario, nome, sobrenome, data_nasc, sexo, data_admissao) FROM stdin;
\.
COPY public.funcionario (id_funcionario, nome, sobrenome, data_nasc, sexo, data_admissao) FROM '$$PATH$$/3331.dat';

--
-- Data for Name: salario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.salario (id_salario, fk_funcionario, valor, data_inicio, data_fim) FROM stdin;
\.
COPY public.salario (id_salario, fk_funcionario, valor, data_inicio, data_fim) FROM '$$PATH$$/3333.dat';

--
-- Name: depart_func depart_func_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.depart_func
    ADD CONSTRAINT depart_func_pk PRIMARY KEY (id_depart_func);


--
-- Name: departamento departamento_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departamento
    ADD CONSTRAINT departamento_pk PRIMARY KEY (id_departamento);


--
-- Name: departamento departamento_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departamento
    ADD CONSTRAINT departamento_un UNIQUE (nome);


--
-- Name: funcionario funcionario_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_pk PRIMARY KEY (id_funcionario);


--
-- Name: salario salario_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salario
    ADD CONSTRAINT salario_pk PRIMARY KEY (id_salario);


--
-- Name: depart_func_fk_departamento_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX depart_func_fk_departamento_idx ON public.depart_func USING btree (fk_departamento);


--
-- Name: depart_func_fk_funcionario_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX depart_func_fk_funcionario_idx ON public.depart_func USING btree (fk_funcionario);


--
-- Name: salario_fk_funcionario_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX salario_fk_funcionario_idx ON public.salario USING btree (fk_funcionario);


--
-- Name: depart_func depart_func_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.depart_func
    ADD CONSTRAINT depart_func_fk FOREIGN KEY (fk_departamento) REFERENCES public.departamento(id_departamento) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: depart_func depart_func_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.depart_func
    ADD CONSTRAINT depart_func_fk_1 FOREIGN KEY (fk_funcionario) REFERENCES public.funcionario(id_funcionario) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: salario salario_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salario
    ADD CONSTRAINT salario_fk FOREIGN KEY (fk_funcionario) REFERENCES public.funcionario(id_funcionario) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

